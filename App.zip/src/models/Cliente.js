export class Cliente {
  constructor(nombreCliente, deuda, fechaCompra) {
    this.nombreCliente = nombreCliente;
    this.deuda = deuda;
    this.fechaCompra = fechaCompra;
  }
}
